import { ReactNode } from 'react';

export interface BadgeProps {
  children: ReactNode;
  intent?: 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'neutral';
  size?: 'sm' | 'md';
  className?: string;
}

export function Badge({ children, intent = 'neutral', size = 'md', className = '' }: BadgeProps) {
  const baseStyles = 'inline-flex items-center justify-center font-medium rounded-full';

  const intentStyles = {
    success: 'bg-intent-success-bg text-intent-success border border-intent-success-border',
    warning: 'bg-intent-warning-bg text-intent-warning border border-intent-warning-border',
    danger: 'bg-intent-danger-bg text-intent-danger border border-intent-danger-border',
    info: 'bg-intent-info-bg text-intent-info border border-intent-info-border',
    primary: 'bg-intent-primary-bg text-intent-primary border border-intent-primary-border',
    neutral: 'bg-surface-sunken text-text-secondary border border-border-default',
  };

  const sizeStyles = {
    sm: 'px-2 py-0.5 text-caption',
    md: 'px-3 py-1 text-body-sm',
  };

  return (
    <span className={`${baseStyles} ${intentStyles[intent]} ${sizeStyles[size]} ${className}`}>
      {children}
    </span>
  );
}
