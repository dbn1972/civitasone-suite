import { ButtonHTMLAttributes, forwardRef, ReactNode } from 'react';
import { motion } from 'motion/react';
import { Loader2 } from 'lucide-react';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'tertiary' | 'danger' | 'ghost' | 'link';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  leadingIcon?: ReactNode;
  trailingIcon?: ReactNode;
  iconOnly?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = 'primary',
      size = 'md',
      loading = false,
      leadingIcon,
      trailingIcon,
      iconOnly = false,
      children,
      disabled,
      className = '',
      ...props
    },
    ref
  ) => {
    const baseStyles =
      'inline-flex items-center justify-center gap-2 font-medium rounded-lg transition-all focus-visible:outline-none focus-visible:shadow-[var(--shadow-focus)] disabled:opacity-50 disabled:cursor-not-allowed';

    const variantStyles = {
      primary:
        'bg-intent-primary text-white hover:opacity-90 active:opacity-80 shadow-[var(--shadow-sm)] hover:shadow-[var(--shadow-md)]',
      secondary:
        'bg-surface-raised text-text-primary border-2 border-border-default hover:bg-surface-sunken active:bg-surface-sunken',
      tertiary:
        'bg-transparent text-text-primary border-2 border-border-subtle hover:border-border-default hover:bg-surface-sunken',
      danger:
        'bg-intent-danger text-white hover:opacity-90 active:opacity-80 shadow-[var(--shadow-sm)] hover:shadow-[var(--shadow-md)]',
      ghost: 'bg-transparent text-text-primary hover:bg-surface-sunken active:bg-surface-sunken',
      link: 'bg-transparent text-intent-primary hover:underline active:opacity-70 p-0',
    };

    const sizeStyles = {
      sm: iconOnly ? 'size-8' : 'px-3 py-1.5 text-body-sm',
      md: iconOnly ? 'size-10' : 'px-4 py-2 text-base',
      lg: iconOnly ? 'size-12' : 'px-6 py-3 text-base',
    };

    const iconSizes = {
      sm: 'size-4',
      md: 'size-5',
      lg: 'size-6',
    };

    return (
      <motion.button
        ref={ref}
        whileHover={!disabled && !loading ? { scale: 1.02 } : {}}
        whileTap={!disabled && !loading ? { scale: 0.98 } : {}}
        disabled={disabled || loading}
        className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
        {...props}
      >
        {loading && <Loader2 className={`${iconSizes[size]} animate-spin`} />}
        {!loading && leadingIcon && <span className={iconSizes[size]}>{leadingIcon}</span>}
        {!iconOnly && children}
        {!loading && trailingIcon && <span className={iconSizes[size]}>{trailingIcon}</span>}
      </motion.button>
    );
  }
);

Button.displayName = 'Button';
