import { ReactNode } from 'react';

export interface CardProps {
  children: ReactNode;
  className?: string;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hover?: boolean;
}

export function Card({ children, className = '', padding = 'md', hover = false }: CardProps) {
  const paddingStyles = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
  };

  return (
    <div
      className={`bg-surface-raised border-2 border-border-subtle rounded-lg ${paddingStyles[padding]} ${
        hover ? 'hover:border-intent-primary hover:shadow-[var(--shadow-md)] transition-all' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
}
