import { InputHTMLAttributes, forwardRef } from 'react';
import { Check, Minus } from 'lucide-react';

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  indeterminate?: boolean;
}

export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, indeterminate = false, className = '', ...props }, ref) => {
    return (
      <label className="inline-flex items-center gap-2 cursor-pointer group">
        <div className="relative">
          <input
            ref={ref}
            type="checkbox"
            className="sr-only peer"
            {...props}
          />
          <div className="size-5 border-2 border-border-default rounded bg-surface-raised transition-all peer-checked:bg-intent-primary peer-checked:border-intent-primary peer-indeterminate:bg-intent-primary peer-indeterminate:border-intent-primary peer-focus-visible:shadow-[var(--shadow-focus)] peer-disabled:opacity-50 peer-disabled:cursor-not-allowed flex items-center justify-center">
            {indeterminate ? (
              <Minus className="size-3 text-white" strokeWidth={3} />
            ) : (
              <Check className="size-3 text-white opacity-0 peer-checked:opacity-100 transition-opacity" strokeWidth={3} />
            )}
          </div>
        </div>
        {label && (
          <span className="text-base text-text-primary select-none group-hover:text-text-secondary transition-colors">
            {label}
          </span>
        )}
      </label>
    );
  }
);

Checkbox.displayName = 'Checkbox';
