import { InputHTMLAttributes, forwardRef } from 'react';

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
  helperText?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ error = false, helperText, className = '', ...props }, ref) => {
    const baseStyles =
      'w-full px-4 py-2 bg-surface-raised border-2 rounded-lg text-text-primary placeholder:text-text-muted transition-all focus:outline-none focus:shadow-[var(--shadow-focus)] disabled:opacity-50 disabled:cursor-not-allowed';

    const stateStyles = error
      ? 'border-intent-danger focus:border-intent-danger'
      : 'border-border-default focus:border-intent-primary';

    return (
      <div className="w-full">
        <input
          ref={ref}
          className={`${baseStyles} ${stateStyles} ${className}`}
          aria-invalid={error}
          aria-describedby={helperText ? `${props.id}-helper` : undefined}
          {...props}
        />
        {helperText && (
          <p
            id={`${props.id}-helper`}
            className={`mt-1 text-body-sm ${error ? 'text-intent-danger' : 'text-text-muted'}`}
          >
            {helperText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';
