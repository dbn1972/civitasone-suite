import { ReactNode } from 'react';

export interface Column<T> {
  key: string;
  label: string;
  render?: (row: T) => ReactNode;
}

export interface TableProps<T> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (row: T) => void;
  density?: 'comfortable' | 'compact';
}

export function Table<T extends Record<string, any>>({
  columns,
  data,
  onRowClick,
  density = 'comfortable',
}: TableProps<T>) {
  const densityPadding = density === 'comfortable' ? 'py-4' : 'py-2';

  return (
    <div className="border-2 border-border-subtle rounded-lg overflow-hidden">
      <table className="w-full">
        <thead className="bg-surface-sunken border-b-2 border-border-subtle">
          <tr>
            {columns.map((column) => (
              <th
                key={column.key}
                className={`px-4 ${densityPadding} text-left text-body-sm font-semibold text-text-primary`}
              >
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length}
                className="px-4 py-12 text-center text-text-muted"
              >
                No data available
              </td>
            </tr>
          ) : (
            data.map((row, index) => (
              <tr
                key={index}
                onClick={() => onRowClick?.(row)}
                className={`border-b border-border-subtle last:border-b-0 ${
                  onRowClick ? 'hover:bg-surface-sunken cursor-pointer' : ''
                } transition-colors`}
              >
                {columns.map((column) => (
                  <td key={column.key} className={`px-4 ${densityPadding} text-text-primary`}>
                    {column.render ? column.render(row) : row[column.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
